
import { createClient } from '@supabase/supabase-js';

// Cliente de Supabase para el lado del CLIENTE (Navegador)
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Supabase URL or Anon Key is missing from environment variables.');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Cliente de Supabase para el lado del SERVIDOR (Rutas API, Server Actions)
const supabaseServiceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseServiceRoleKey) {
  // En desarrollo, podemos permitir que falte para no bloquear el frontend,
  // pero en producción debería ser obligatorio.
  console.warn('Supabase Service Role Key is missing. Admin operations will fail.');
}

// Creamos una instancia de admin solo si la clave de servicio está disponible
export const supabaseAdmin = supabaseServiceRoleKey
  ? createClient(supabaseUrl, supabaseServiceRoleKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    })
  : null;

// Advertencia para desarrolladores: Asegurarse de que el cliente admin no se use en el cliente.
if (typeof window !== 'undefined' && supabaseAdmin) {
    console.warn('Warning: supabaseAdmin is being exposed on the client side. This is a security risk.');
}
