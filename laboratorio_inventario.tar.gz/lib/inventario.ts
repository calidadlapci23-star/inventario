
import { supabase } from './supabase'; // Usamos el cliente del lado del cliente

// Definición de la estructura de un Producto
export interface Producto {
  id: string;
  nombre: string;
  descripcion?: string;
  stock_actual: number;
  stock_minimo: number;
  disciplina_nombre: string; // Nombre de la disciplina
  // Añade otros campos si es necesario, por ejemplo:
  // created_at: string;
}

/**
 * Obtiene todos los productos del inventario con el nombre de su disciplina.
 * Esta función es segura para ser usada en Server Components.
 */
export async function getProductos(): Promise<Producto[]> {
  console.log("Obteniendo productos desde la base de datos...");

  // Nota: Usamos `supabase` (cliente) porque esta función se ejecuta en el servidor,
  // pero los Server Components pueden usar el cliente de cliente de forma segura.
  // Si se necesitara acceso de admin, usaríamos `supabaseAdmin`.

  const { data, error } = await supabase
    .from('productos') // Nombre de la tabla de productos
    .select(`
      id,
      nombre,
      descripcion,
      stock_actual,
      stock_minimo,
      disciplinas ( nombre ) // Join con la tabla de disciplinas
    `);

  if (error) {
    console.error('Error al obtener los productos:', error.message);
    // En caso de error, devolvemos un array vacío para que la UI no se rompa
    return [];
  }

  // Si no hay datos, devolvemos un array vacío
  if (!data) {
    console.log("No se encontraron productos.");
    return [];
  }
  
  console.log(`Se encontraron ${data.length} productos.`);

  // Mapeamos los datos para aplanar la estructura y que coincida con la interfaz `Producto`
  const productosFormateados = data.map(item => ({
    ...item,
    // Accedemos al nombre de la disciplina desde el objeto anidado
    disciplina_nombre: Array.isArray(item.disciplinas) ? item.disciplinas[0]?.nombre : item.disciplinas?.nombre || 'Sin disciplina',
  }));

  return productosFormateados;
}


/**
 * Obtiene un único producto por su ID.
 * Ideal para páginas de detalles de un producto.
 */
export async function getProductoById(id: string): Promise<Producto | null> {
  if (!id) return null;

  const { data, error } = await supabase
    .from('productos')
    .select(`
        id,
        nombre,
        descripcion,
        stock_actual,
        stock_minimo,
        disciplinas ( nombre )
    `)
    .eq('id', id)
    .single(); // .single() para obtener un único resultado o null

  if (error || !data) {
    console.error(`Error al obtener el producto con ID ${id}:`, error?.message);
    return null;
  }

  // Aplanamos la estructura de la disciplina
  const productoFormateado = {
    ...data,
    disciplina_nombre: Array.isArray(data.disciplinas) ? data.disciplinas[0]?.nombre : data.disciplinas?.nombre || 'Sin disciplina',
  };

  return productoFormateado;
}
