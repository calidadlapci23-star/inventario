'use client'

import { useState, useEffect } from 'react'
import { useForm } from 'react-hook-form'
import { supabase } from '@/lib/supabase'

interface RecepcionFormData {
  disciplina_id: string
  producto_id: string
  categoria_id: string
  proveedor_id: string
  numero_lote: string
  fecha_recepcion: string
  fecha_vencimiento: string
  cantidad: number
  unidad_medida: string
  precio_unitario?: number
  observaciones?: string
}

interface Producto {
  id: string
  nombre: string
  disciplina_id: string
}

interface Disciplina {
  id: string
  nombre: string
}

export function RecepcionForm() {
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [disciplinas, setDisciplinas] = useState<Disciplina[]>([])
  const [productos, setProductos] = useState<Producto[]>([])
  const [productosFiltrados, setProductosFiltrados] = useState<Producto[]>([])
  const [usuario, setUsuario] = useState('')

  const { register, handleSubmit, watch, reset, formState: { errors } } = useForm<RecepcionFormData>()

  const disciplinaId = watch('disciplina_id')

  useEffect(() => {
    cargarDatosIniciales()
  }, [])

  useEffect(() => {
    if (disciplinaId) {
      filtrarProductos(disciplinaId)
    }
  }, [disciplinaId, productos])

  const cargarDatosIniciales = async () => {
    try {
      // Cargar disciplinas
      const { data: disciplinasData } = await supabase
        .from('disciplinas')
        .select('id, nombre')
        .order('nombre')

      if (disciplinasData) setDisciplinas(disciplinasData)

      // Cargar productos
      const { data: productosData } = await supabase
        .from('productos')
        .select('id, nombre, disciplina_id')
        .order('nombre')

      if (productosData) setProductos(productosData)

      // Obtener usuario actual
      const { data: { user } } = await supabase.auth.getUser()
      if (user) setUsuario(user.email || 'Sistema')
    } catch (error) {
      console.error('Error cargando datos:', error)
    }
  }

  const filtrarProductos = (disciplinaId: string) => {
    const filtrados = productos.filter(p => p.disciplina_id === disciplinaId)
    setProductosFiltrados(filtrados)
  }

  const onSubmit = async (data: RecepcionFormData) => {
    setLoading(true)
    setSuccess(false)

    try {
      const response = await fetch('/api/recepcion', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...data,
          usuario,
        }),
      })

      const result = await response.json()

      if (result.success) {
        setSuccess(true)
        reset()
        setTimeout(() => setSuccess(false), 3000)
      } else {
        alert(`Error: ${result.error}`)
      }
    } catch (error) {
      alert('Error al procesar la recepción')
      console.error(error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6 max-w-4xl mx-auto p-6 bg-white rounded-lg shadow">
      <div>
        <h2 className="text-2xl font-bold text-gray-900">📦 Cargar Recepción</h2>
        <p className="text-gray-600">Registrar entrada de productos al inventario</p>
      </div>

      {success && (
        <div className="p-4 bg-green-50 text-green-700 rounded-lg">
          ✅ Recepción registrada exitosamente
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Disciplina *
          </label>
          <select
            {...register('disciplina_id', { required: 'Selecciona una disciplina' })}
            className="w-full p-2 border rounded-lg"
          >
            <option value="">Seleccionar disciplina</option>
            {disciplinas.map((d) => (
              <option key={d.id} value={d.id}>
                {d.nombre}
              </option>
            ))}
          </select>
          {errors.disciplina_id && (
            <p className="text-red-500 text-sm mt-1">{errors.disciplina_id.message}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Producto *
          </label>
          <select
            {...register('producto_id', { required: 'Selecciona un producto' })}
            className="w-full p-2 border rounded-lg"
            disabled={!disciplinaId}
          >
            <option value="">{disciplinaId ? 'Seleccionar producto' : 'Primero selecciona una disciplina'}</option>
            {productosFiltrados.map((p) => (
              <option key={p.id} value={p.id}>
                {p.nombre}
              </option>
            ))}
          </select>
          {errors.producto_id && (
            <p className="text-red-500 text-sm mt-1">{errors.producto_id.message}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Número de Lote *
          </label>
          <input
            type="text"
            {...register('numero_lote', { required: 'Ingresa el número de lote' })}
            className="w-full p-2 border rounded-lg"
            placeholder="Ej: LOT-2024-001"
          />
          {errors.numero_lote && (
            <p className="text-red-500 text-sm mt-1">{errors.numero_lote.message}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Cantidad *
          </label>
          <input
            type="number"
            {...register('cantidad', { 
              required: 'Ingresa la cantidad',
              min: { value: 1, message: 'La cantidad debe ser mayor a 0' }
            })}
            className="w-full p-2 border rounded-lg"
            placeholder="Ej: 100"
          />
          {errors.cantidad && (
            <p className="text-red-500 text-sm mt-1">{errors.cantidad.message}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Fecha de Recepción *
          </label>
          <input
            type="date"
            {...register('fecha_recepcion', { required: 'Selecciona la fecha de recepción' })}
            className="w-full p-2 border rounded-lg"
          />
          {errors.fecha_recepcion && (
            <p className="text-red-500 text-sm mt-1">{errors.fecha_recepcion.message}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Fecha de Vencimiento *
          </label>
          <input
            type="date"
            {...register('fecha_vencimiento', { required: 'Selecciona la fecha de vencimiento' })}
            className="w-full p-2 border rounded-lg"
          />
          {errors.fecha_vencimiento && (
            <p className="text-red-500 text-sm mt-1">{errors.fecha_vencimiento.message}</p>
          )}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Observaciones
        </label>
        <textarea
          {...register('observaciones')}
          className="w-full p-2 border rounded-lg"
          rows={3}
          placeholder="Notas adicionales sobre la recepción..."
        />
      </div>

      <div className="flex justify-end space-x-4">
        <button
          type="button"
          onClick={() => reset()}
          className="px-4 py-2 border rounded-lg hover:bg-gray-50"
          disabled={loading}
        >
          Limpiar
        </button>
        <button
          type="submit"
          className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
          disabled={loading}
        >
          {loading ? 'Procesando...' : 'Registrar Recepción'}
        </button>
      </div>
    </form>
  )
}
