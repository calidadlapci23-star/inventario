import { NextRequest, NextResponse } from 'next/server';
import { productosSugeridos } from '@/lib/productData';
import { supabaseAdmin } from '@/lib/supabase';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const disciplinaId = searchParams.get('disciplinaId');

  if (!disciplinaId) {
    return NextResponse.json({ success: false, error: 'El ID de la disciplina es requerido' }, { status: 400 });
  }

  try {
    // 1. Obtener el nombre de la disciplina desde Supabase usando su ID
    const { data: disciplinaData, error: disciplinaError } = await supabaseAdmin
      .from('disciplinas')
      .select('nombre')
      .eq('id', disciplinaId)
      .single();

    if (disciplinaError || !disciplinaData) {
      return NextResponse.json({ success: false, error: 'Disciplina no encontrada' }, { status: 404 });
    }

    const nombreDisciplina = disciplinaData.nombre.toUpperCase().replace(/_/g, ' ');

    // 2. Buscar las sugerencias en el objeto de datos local
    const sugerencias = productosSugeridos[nombreDisciplina] || [];

    return NextResponse.json({ success: true, data: sugerencias });

  } catch (error: any) {
    return NextResponse.json({ success: false, error: 'Error interno del servidor', details: error.message }, { status: 500 });
  }
}
