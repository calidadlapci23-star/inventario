import ConsumoForm from "../../../components/forms/ConsumoForm";

export default function ConsumoPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Registrar Consumo</h1>
      <ConsumoForm />
    </div>
  );
}
