import RecepcionForm from '../components/RecepcionForm';
import Header from '../components/Header';

export default function RecepcionPage() {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-start py-10 sm:py-12">
      <div className="w-full max-w-4xl mx-auto bg-white shadow-2xl rounded-2xl overflow-hidden transition-all duration-300">
        
        {/* Encabezado reutilizable */}
        <Header title="Cargar Recepción de Reactivos e Insumos" />

        {/* Contenedor del Formulario con padding mejorado */}
        <div className="p-6 sm:p-8 md:p-10">
          <RecepcionForm />
        </div>

      </div>
    </div>
  );
}
