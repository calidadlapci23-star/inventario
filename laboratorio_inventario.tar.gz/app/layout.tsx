
import '../app/globals.css'
import { Inter } from 'next/font/google'
import { cn } from '@/lib/utils'
import Sidebar from '@/components/Sidebar' // Importamos el Sidebar

const inter = Inter({ subsets: ['latin'] })

export const metadata = {
  title: 'Laboratorio',
  description: 'Sistema de Gestión de Inventario para Laboratorio Clínico',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="es" suppressHydrationWarning>
      <body className={cn('min-h-screen bg-background font-sans antialiased', inter.className)}>
        <div className="flex min-h-screen bg-gray-50">
          {/* La barra lateral que acabamos de confirmar que existe */}
          <Sidebar /> 

          {/* El contenido principal de la página */}
          <main className="flex-1 p-8">
            {children}
          </main>
        </div>
      </body>
    </html>
  )
}
