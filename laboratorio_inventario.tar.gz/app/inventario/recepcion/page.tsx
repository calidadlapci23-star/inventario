import RecepcionForm from '@/app/components/RecepcionForm';

export default function RecepcionPage() {
  return (
    <div className="bg-white p-8 rounded-xl shadow-lg w-full max-w-4xl mx-auto my-8">
      <h1 className="text-2xl font-bold text-gray-800 mb-2">Nueva Recepción de Inventario</h1>
      <p className="text-gray-600 mb-8">Complete el formulario para registrar un nuevo lote de productos en el sistema.</p>
      <RecepcionForm />
    </div>
  );
}
