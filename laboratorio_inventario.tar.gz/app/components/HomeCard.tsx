// components/HomeCard.tsx
import { LucideIcon } from 'lucide-react';
import Link from 'next/link';

interface HomeCardProps {
  title: string;
  description: string;
  icon: LucideIcon;
  href: string;
  color: string;
}

export default function HomeCard({ 
  title, 
  description, 
  icon: Icon, 
  href, 
  color 
}: HomeCardProps) {
  return (
    <Link 
      href={href}
      className={`block p-6 rounded-xl shadow-lg transition-all duration-300 hover:scale-105 hover:shadow-xl ${color}`}
    >
      <div className="flex items-start space-x-4">
        <div className="p-3 bg-white bg-opacity-20 rounded-lg">
          <Icon className="w-6 h-6 text-white" />
        </div>
        <div className="flex-1">
          <h3 className="text-xl font-bold text-white mb-2">{title}</h3>
          <p className="text-white text-opacity-90">{description}</p>
        </div>
      </div>
    </Link>
  );
}
