'use client';

import { useState, useEffect, FormEvent, ChangeEvent } from 'react';
import { Loader2, AlertCircle, CheckCircle } from 'lucide-react';

type Disciplina = { id: number; nombre: string; };
type Sugerencia = { nombre: string; proveedor: string; };

const initialState = {
  disciplina: '',
  producto: '',
  categoria: '',
  proveedor: '',
  lote: '',
  cantidad: '1',
  unidad: 'PIEZAS',
  piezasPorCaja: '1',
  fechaRecepcion: new Date().toISOString().split('T')[0],
  fechaVencimiento: new Date(new Date().setFullYear(new Date().getFullYear() + 1)).toISOString().split('T')[0],
  alertaMinima: '5',
  ubicacion: '',
  observaciones: '',
};

export default function RecepcionForm() {
  const [formData, setFormData] = useState(initialState);
  const [isLoading, setIsLoading] = useState(false);
  const [isFetchingDisciplinas, setIsFetchingDisciplinas] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [disciplinas, setDisciplinas] = useState<Disciplina[]>([]);
  const [sugerencias, setSugerencias] = useState<Sugerencia[]>([]);

  // Fetch Disciplinas
  useEffect(() => {
    const fetchDisciplinas = async () => {
      setIsFetchingDisciplinas(true);
      try {
        const response = await fetch('/api/disciplinas');
        const result = await response.json();
        if (!response.ok || !result.success) throw new Error(result.error || 'No se pudieron cargar las disciplinas.');
        setDisciplinas(result.data);
      } catch (err: any) {
        setError(`Error de red: ${err.message}`);
      } finally {
        setIsFetchingDisciplinas(false);
      }
    };
    fetchDisciplinas();
  }, []);

  // Fetch Sugerencias de Productos
  useEffect(() => {
    if (!formData.disciplina) {
      setSugerencias([]);
      return;
    }

    const fetchSugerencias = async () => {
      try {
        const response = await fetch(`/api/productos/sugerencias?disciplinaId=${formData.disciplina}`);
        const result = await response.json();
        if (response.ok && result.success) {
          setSugerencias(result.data);
        } else {
          setSugerencias([]);
        }
      } catch (err) {
        setSugerencias([]);
      }
    };

    fetchSugerencias();
  }, [formData.disciplina]);

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    
    setFormData(prev => ({ ...prev, [name]: value }));

    // Autocompletar proveedor si el producto cambia
    if (name === 'producto') {
      const sugerenciaElegida = sugerencias.find(s => s.nombre.toLowerCase() === value.toLowerCase());
      if (sugerenciaElegida) {
        setFormData(prev => ({ ...prev, producto: sugerenciaElegida.nombre, proveedor: sugerenciaElegida.proveedor }));
      }
    }
    
    // Limpiar producto y proveedor si la disciplina cambia
    if (name === 'disciplina') {
        setFormData(prev => ({ ...prev, producto: '', proveedor: '' }));
    }
  };

  const handleReset = () => {
    setFormData(initialState);
    setError(null);
    setSuccessMessage(null);
    setSugerencias([]);
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    setSuccessMessage(null);

    try {
      const response = await fetch('/api/inventario/recepcion', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      const result = await response.json();
      if (!response.ok) throw new Error(result.details ? JSON.stringify(result.details) : result.error || 'Error desconocido del servidor');

      setSuccessMessage('¡Recepción guardada con éxito!');
      handleReset();

    } catch (err: any) {
      setError(err.message || 'Ocurrió un error inesperado al guardar.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8 text-sm">

      {error && <div className="flex items-center p-4 text-red-800 rounded-lg bg-red-50"><AlertCircle className="w-5 h-5 mr-3"/>{error}</div>}
      {successMessage && <div className="flex items-center p-4 text-green-800 rounded-lg bg-green-50"><CheckCircle className="w-5 h-5 mr-3"/>{successMessage}</div>}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-x-8 gap-y-6">
        
        <div className="md:col-span-3">
          <label htmlFor="disciplina" className="block font-medium text-gray-800">Disciplina <span className="text-red-600">*</span></label>
          <select id="disciplina" name="disciplina" value={formData.disciplina} onChange={handleChange} required disabled={isFetchingDisciplinas} className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 bg-gray-50 disabled:bg-gray-200">
            <option value="">{isFetchingDisciplinas ? 'Cargando...' : 'Seleccionar disciplina'}</option>
            {disciplinas.map(d => <option key={d.id} value={d.id}>{d.nombre}</option>)}
          </select>
        </div>

        <div className="md:col-span-3">
          <label htmlFor="producto" className="block font-medium text-gray-800">Producto <span className="text-red-600">*</span></label>
          <input list="productos-sugeridos" type="text" name="producto" id="producto" value={formData.producto} onChange={handleChange} required disabled={!formData.disciplina} className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm disabled:bg-gray-200"/>
          <datalist id="productos-sugeridos">
            {sugerencias.map((s, i) => <option key={i} value={s.nombre} />)}
          </datalist>
        </div>

        <div>
          <label htmlFor="categoria" className="block font-medium text-gray-800">Categoría <span className="text-red-600">*</span></label>
          <select id="categoria" name="categoria" value={formData.categoria} onChange={handleChange} required className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm">
            <option value="">Seleccionar...</option>
            <option value="reactivo">Reactivo</option>
            <option value="control">Control</option>
            <option value="calibrador">Calibrador</option>
          </select>
        </div>

        <div className="md:col-span-2">
          <label htmlFor="proveedor" className="block font-medium text-gray-800">Proveedor <span className="text-red-600">*</span></label>
          <input type="text" name="proveedor" id="proveedor" value={formData.proveedor} onChange={handleChange} required className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm bg-gray-50"/>
        </div>

        <div>
          <label htmlFor="lote" className="block font-medium text-gray-800">Lote <span className="text-red-600">*</span></label>
          <input type="text" name="lote" id="lote" value={formData.lote} onChange={handleChange} required className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm"/>
        </div>

        <div>
          <label htmlFor="unidad" className="block font-medium text-gray-800">Unidad de Medida <span className="text-red-600">*</span></label>
          <select id="unidad" name="unidad" value={formData.unidad} onChange={handleChange} required className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm">
            <option value="PIEZAS">Piezas</option>
            <option value="CAJA">Caja</option>
            <option value="KIT">Kit</option>
            <option value="LITRO">Litro</option>
            <option value="MILILITRO">Mililitro</option>
            <option value="GRAMO">Gramo</option>
            <option value="TEST">Test</option>
            <option value="JUEGO">Juego</option>
          </select>
        </div>

        {formData.unidad === 'CAJA' && (
          <div>
            <label htmlFor="piezasPorCaja" className="block font-medium text-gray-800">Piezas por Caja <span className="text-red-600">*</span></label>
            <input type="number" name="piezasPorCaja" id="piezasPorCaja" value={formData.piezasPorCaja} onChange={handleChange} required min="1" className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm"/>
          </div>
        )}

        <div>
          <label htmlFor="cantidad" className="block font-medium text-gray-800">Cantidad Recibida <span className="text-red-600">*</span></label>
          <input type="number" name="cantidad" id="cantidad" value={formData.cantidad} onChange={handleChange} required min="1" className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm"/>
        </div>

        <div>
          <label htmlFor="fechaRecepcion" className="block font-medium text-gray-800">Fecha de Recepción <span className="text-red-600">*</span></label>
          <input type="date" name="fechaRecepcion" id="fechaRecepcion" value={formData.fechaRecepcion} onChange={handleChange} required className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm bg-gray-50"/>
        </div>

        <div>
          <label htmlFor="fechaVencimiento" className="block font-medium text-gray-800">Fecha de Vencimiento</label>
          <input type="date" name="fechaVencimiento" id="fechaVencimiento" value={formData.fechaVencimiento} onChange={handleChange} className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm"/>
        </div>

        <div>
          <label htmlFor="ubicacion" className="block font-medium text-gray-800">Ubicación</label>
          <input type="text" name="ubicacion" id="ubicacion" value={formData.ubicacion} onChange={handleChange} className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm"/>
        </div>

        <div>
          <label htmlFor="alertaMinima" className="block font-medium text-gray-800">Alerta de Stock Mínimo</label>
          <input type="number" name="alertaMinima" id="alertaMinima" value={formData.alertaMinima} onChange={handleChange} min="0" placeholder="Ej: 5" className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm"/>
        </div>

        <div className="md:col-span-3">
          <label htmlFor="observaciones" className="block font-medium text-gray-800">Observaciones</label>
          <textarea name="observaciones" id="observaciones" value={formData.observaciones} onChange={handleChange} rows={4} className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm"></textarea>
        </div>
      </div>

      <div className="flex items-center justify-end gap-x-4 pt-5 mt-4 border-t border-gray-200">
        <button type="button" onClick={handleReset} disabled={isLoading} className="px-5 py-2.5 text-sm font-medium text-gray-700 bg-white rounded-lg border border-gray-300 hover:bg-gray-100 focus:z-10 focus:ring-4 focus:ring-gray-100 disabled:opacity-50">Cancelar</button>
        <button type="submit" disabled={isLoading || isFetchingDisciplinas} className="inline-flex items-center px-5 py-2.5 text-sm font-medium text-center text-white bg-blue-700 rounded-lg hover:bg-blue-800 focus:ring-4 focus:ring-blue-300 disabled:bg-blue-400">
          {isLoading && <Loader2 className="animate-spin -ml-1 mr-3 h-5 w-5" />}
          {isLoading ? 'Guardando...' : 'Guardar Recepción'}
        </button>
      </div>

    </form>
  );
}
