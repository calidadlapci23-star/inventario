interface DashboardCardProps {
  titulo: string;
  valor: number;
  icon: React.ReactNode;
  color: 'blue' | 'amber' | 'red' | 'green';
}

export default function DashboardCard({ titulo, valor, icon, color }: DashboardCardProps) {
  const colorClasses = {
    blue: 'bg-blue-50 border-blue-100',
    amber: 'bg-amber-50 border-amber-100',
    red: 'bg-red-50 border-red-100',
    green: 'bg-green-50 border-green-100',
  };

  return (
    <div className={`${colorClasses[color]} rounded-xl border-2 p-6 transition-transform hover:scale-105`}>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-700">{titulo}</h3>
        {icon}
      </div>
      <p className="text-4xl font-bold text-gray-900">{valor}</p>
    </div>
  );
}
